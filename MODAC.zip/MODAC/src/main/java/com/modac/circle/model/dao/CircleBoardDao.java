package com.modac.circle.model.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

import com.modac.circle.model.vo.Circle;
import com.modac.common.JDBCTemplate;

public class CircleBoardDao {
private Properties prop = new Properties();
	
	public CircleBoardDao() {
		try {
			prop.loadFromXML(new FileInputStream(CircleBoardDao.class.getResource("/sql/circle/cboard-mapper.xml").getPath()));
		} catch (IOException e) {
		
			e.printStackTrace();
		}
	}
	
	public int insertBoard(Circle c, Connection conn) {
		int result = 0;
		PreparedStatement psmt = null;
		
		String sql = prop.getProperty("insertBoard");
		
		try {
			psmt=conn.prepareStatement(sql);
			
			
			psmt.setString(1, c.getPostTitle());
			psmt.setString(2, c.getPostContent());
			psmt.setString(3, c.getMemberNo());
			
			result = psmt.executeUpdate();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally {
			JDBCTemplate.close(psmt);
		}
		
		return result;
	}

}
