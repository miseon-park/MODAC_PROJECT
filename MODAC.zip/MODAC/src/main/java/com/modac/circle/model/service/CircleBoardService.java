package com.modac.circle.model.service;

import java.sql.Connection;

import com.modac.circle.model.dao.CircleBoardDao;
import com.modac.circle.model.vo.Circle;
import com.modac.common.JDBCTemplate;

public class CircleBoardService {
	
public int insertBoard(Circle c) {
		
		Connection conn = JDBCTemplate.getConnection();
		int result1 = new CircleBoardDao().insertBoard(c, conn);
		
		
		
		
		
		//트랜잭션 처리
		if(result1>0 ) {
			//첨부파일이 없는경우, insert가 성공했을때도 result2는 여전히 0이라 rollback 처리가 될 수 있으믈
			// result2 = 1ㄹ 초기화 시켜둠
			JDBCTemplate.commit(conn);
			
		}else {
			JDBCTemplate.rollback(conn);
		}
		JDBCTemplate.close();
		
		
		//혹시라도 하나라도 실패하여 0이될 경우 아예 실패값을 반환받기위해 곱세결과를 리턴.
		return result1;
	}

}
